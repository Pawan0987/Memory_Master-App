package com.example.memorymaster.Classes

import com.example.memorymaster.R

val defaultIcons = listOf(
    R.drawable.ic_baseline_bell,
    R.drawable.ic_baseline_book,
    R.drawable.ic_baseline_bulb,
    R.drawable.ic_baseline_brush_24,
    R.drawable.ic_baseline_camera,
    R.drawable.ic_baseline_celebration,
    R.drawable.ic_baseline_chair,
    R.drawable.ic_baseline_cloud,
    R.drawable.ic_baseline_headphone,
    R.drawable.ic_baseline_smartphone,
    R.drawable.ic_baseline_stack,
    R.drawable.ic_baseline_tag_faces_24
)