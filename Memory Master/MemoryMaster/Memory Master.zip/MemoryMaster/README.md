# About Game
Mind Puzzle game made using Kotlin Android

# Game Rules 
- Game Contains three levels Easy Medium Hard with 8, 18 and 24 images respectively.
- Match images with identical pairs in as minimum moves as possible

